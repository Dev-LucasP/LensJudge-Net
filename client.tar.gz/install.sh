#!/bin/bash
# CLIENT

systemctl enable --now NetworkManager

nmcli connection mod eth0 autoconnect true \
    ipv4.method manual ipv4.addresses 10.0.0.10/24 \
    ipv4.routes "10.0.1.0/24 10.0.0.1, 10.0.2.0/24 10.0.0.1"
nmcli connection mod eth0 ipv4.dns "10.0.0.10,10.0.1.10" ipv4.dns-search "lensjudge.fr"
systemctl restart NetworkManager