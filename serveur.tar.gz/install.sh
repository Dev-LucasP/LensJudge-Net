#!/bin/bash

# SERVEUR

nmcli connection mod eth0 autoconnect true\
    ipv4.method manual ipv4.addresses 10.0.1.10/24\
    ipv4.routes "10.0.0.0/24 10.0.1.1, 10.0.2.0/24 10.0.1.1"
nmcli connection mod eth0 ipv4.dns "10.0.1.10" ipv4.dns-search "lensjudge.fr"

systemctl restart NetworkManager

chown named:named /var/named/*

systemctl enable --now named

chmod -R 755 /var/www/html
chown -R apache:apache /var/www/html

systemctl enable --now httpd