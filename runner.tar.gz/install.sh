#!/bin/bash

# RUNNER

systemctl enable --now NetworkManager

nmcli connection mod eth0 ipv4.method auto autoconnect true

nmcli connection mod eth0 ipv4.dns "10.0.1.10" ipv4.dns-search "lensjudge.fr"
systemctl restart NetworkManager
