#!/bin/bash

PORT_APPLICATION=6666
PORT_APPLICATION_2=6667

# Remise a zero des regles

iptables -F
iptables -X

# regle par defaut

iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# autoriser les connexions deja etablies & les connexions en loopback

iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT

# autoriser les connexions en icmp (ping) pour debug

iptables -A INPUT -p icmp -j ACCEPT

# DNS (udp et tcp) 

iptables -N DNS 

iptables -A DNS -j ACCEPT

iptables -A INPUT -p udp --dport 53 -j DNS
iptables -A INPUT -p tcp --dport 53 -j DNS

iptables -A FORWARD -p tcp --dport 53 -j DNS
iptables -A FORWARD -p udp --dport 53 -j DNS

# Packet port de l'application

iptables -A INPUT -p tcp --dport $PORT_APPLICATION -j ACCEPT
iptables -A INPUT -p udp --dport $PORT_APPLICATION -j ACCEPT

iptables -A FORWARD -p udp --dport $PORT_APPLICATION -j ACCEPT
iptables -A FORWARD -p tcp --dport $PORT_APPLICATION -j ACCEPT

iptables -A INPUT -p tcp --dport $PORT_APPLICATION_2 -j ACCEPT
iptables -A INPUT -p udp --dport $PORT_APPLICATION_2 -j ACCEPT

iptables -A FORWARD -p udp --dport $PORT_APPLICATION_2 -j ACCEPT
iptables -A FORWARD -p tcp --dport $PORT_APPLICATION_2 -j ACCEPT

# Packet serveur web

iptables -A FORWARD -p tcp --dport 80 -j ACCEPT
iptables -A FORWARD -p tcp --dport 443 -j ACCEPT

# SSH 

iptables -A FORWARD -p tcp --dport 22 -s 10.0.2.10 -d 10.0.1.10 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -s 10.0.2.10 -d 10.0.1.10 -j ACCEPT

# Log SSH
iptables -A FORWARD -p tcp --dport 22 -d 10.0.1.10 -j LOG --log-prefix "SSH_ACCESS: "


iptables -A FORWARD -p tcp --dport 80 -s 10.0.2.0/24 -j ACCEPT
iptables -A FORWARD -p tcp --dport 443 -s 10.0.2.0/24 -j ACCEPT


# Runner pas accesible depuis inet

iptables -A INPUT -p tcp -d 10.0.2.0/24 -i inet -j DROP
iptables -A INPUT -p udp -d 10.0.2.0/24 -i inet -j DROP
