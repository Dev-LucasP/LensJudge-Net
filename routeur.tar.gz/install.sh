#!/bin/bash

# ROUTEUR

systemctl enable --now NetworkManager

nmcli connection mod inet autoconnect true\
    ipv4.method manual ipv4.addresses 10.0.0.1/24\

nmcli connection mod dmz autoconnect true\
    ipv4.method manual ipv4.addresses 10.0.1.1/24\

nmcli connection mod local autoconnect true\
    ipv4.method manual ipv4.addresses 10.0.2.1/24\

sysctl net.ipv4.conf.all.forwarding=1

systemctl restart NetworkManager
systemctl enable --now dhcpd

echo "net.ipv4.conf.all.forwarding=1" > /etc/sysctl.conf
